Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Unrestricted
.\StoryTeller_1.0.0.2_AnyCPU_Test\Add-AppDevPackage.ps1
